package com.example.unfollowassistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        TextView title = new TextView(this);
        title.setText("Unfollow Assistant\n\n1) فعّل خدمة إمكانية الوصول.\n2) افتح Facebook يدويًا.\n3) ادخل إلى قائمة إلغاء المتابعة.\n4) ارجع واضغط «تشغيل».\n\nهذه نسخة أولية تجريبية.");
        title.setTextSize(18);
        title.setPadding(40,50,40,30);
        title.setGravity(Gravity.CENTER);

        Button settings = new Button(this);
        settings.setText("فتح إعدادات إمكانية الوصول");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button start = new Button(this);
        start.setText("تشغيل / إيقاف");
        start.setOnClickListener(v -> UnfollowAccessibilityService.toggle());

        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(30,30,30,30);
        box.addView(title, new ViewGroup.LayoutParams(-1, 0, 1));
        box.addView(settings);
        box.addView(start);
        setContentView(box);
    }
}
