package com.example.unfollowassistant;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityEvent;
import android.os.Handler;
import java.util.Locale;

public class UnfollowAccessibilityService extends AccessibilityService {
    private static UnfollowAccessibilityService instance;
    private static boolean running = false;
    private final Handler handler = new Handler();

    public static void toggle() {
        running = !running;
        if (instance != null && running) instance.scanSoon();
    }

    @Override public void onServiceConnected() {
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (running) scanSoon();
    }

    private void scanSoon() {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::scanAndClick, 700);
    }

    private void scanAndClick() {
        if (!running) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        // Prototype: only acts on visible nodes whose text/content-description
        // explicitly contains an "unfollow" label. It does not bypass dialogs,
        // login screens, CAPTCHAs, or other security controls.
        if (clickFirstMatching(root)) {
            scanSoon();
        }
    }

    private boolean clickFirstMatching(AccessibilityNodeInfo node) {
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        String s = ((t == null ? "" : t.toString()) + " " +
                    (d == null ? "" : d.toString())).toLowerCase(Locale.ROOT);

        if (s.contains("unfollow") || s.contains("إلغاء المتابعة") || s.contains("unfollow")) {
            if (node.isClickable()) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                return true;
            }
            AccessibilityNodeInfo p = node.getParent();
            if (p != null && p.isClickable()) {
                p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                p.recycle();
                return true;
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean done = clickFirstMatching(child);
                child.recycle();
                if (done) return true;
            }
        }
        return false;
    }

    @Override public void onInterrupt() {}
    @Override public void onDestroy() {
        running = false;
        instance = null;
        super.onDestroy();
    }
}
