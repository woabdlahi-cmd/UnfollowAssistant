# Unfollow Assistant — prototype

Android Studio prototype for UI automation through AccessibilityService.

## What it does
- User opens Facebook manually.
- User navigates to the desired unfollow list.
- Accessibility service looks for visible controls labeled "Unfollow" / "إلغاء المتابعة".
- It clicks one matching control at a time and rescans after a short delay.
- The user can stop it from the app.

## Important
This is a prototype. Facebook/Meta UI labels and accessibility nodes can change.
Do not use it to bypass CAPTCHAs, login protections, rate limits, or other security controls.
Before distributing it, verify Meta/Facebook and Google Play policies and add explicit consent,
a visible stop control, logging, and robust safeguards.
